<?php
include 'conn.php';
$id=@$_SESSION['user'];
if(isset($_COOKIE['user'])){
  $_SESSION['user']=$_COOKIE['user'];
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">


<link rel="stylesheet" href="bootstrap-4.3.1-dist/css/bootstrap.min.css">

<link rel="stylesheet" href="bootstrap-4.3.1-dist/js/bootstrap.min.js">



    <title> Sarahah</title>
  </head>
  <body>


<nav class="navbar navbar-expand-lg navbar-dark primary-color" style="background-color: #1A78C3;">

  <!-- Navbar brand -->
  <a class="navbar-brand" href="#">Sarahah</a>

  <!-- Collapse button -->
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#basicExampleNav"
    aria-controls="basicExampleNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <!-- Collapsible content -->
  <div class="collapse navbar-collapse" id="basicExampleNav">

    <!-- Links -->
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="login.php">Login
      
        </a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="register.php">Register</a>
      </li>
          <?php
    if($id){
    ?>
      <li class="nav-item active">
        <a class="nav-link" href="profile.php">Profile</a>
      </li>
      <?php

}
      ?>
       <li class="nav-item active">
        <a class="nav-link" href="accounts.php">Accounts</a>
      </li>
          <?php
    if($id){
    ?>
       <li class="nav-item active">
        <a class="nav-link" href="messages.php">Messages</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="settings.php">Settings</a>
      </li>
      <?php

    }
    ?>
    </ul>
    <?php
    if($id){
    ?>
    <form method="post" action="">
     <button class="btn btn-danger my-4 pull-right" name="logout" type="submit">logout</button>
    </form>
    <?php
  }
    ?>
    <!-- Links -->
  </div>
  <!-- Collapsible content -->
 <?php

if(isset($_POST['logout'])){

   session_destroy();
   session_unset($_SESSION['user']);
   setcookie("user", "", time() - 3600,"/");
   header('location:login.php');    
}

?>

</nav>
<!--/.Navbar-->
