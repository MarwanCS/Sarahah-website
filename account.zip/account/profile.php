
<?php
include 'header.php';

$id=@$_SESSION['user'];
if(!$id){
 header('location:login.php');
}

 

$query_get_data="SELECT * from users where idusers='$id' ";
$exe=mysqli_query($conn,$query_get_data);
$result=mysqli_fetch_array($exe);

?>





<style type="text/css">
  .button {
    display: block;
width: 30%;
    background: #4E9CAF;
    padding: 10px;
    text-align: center;
    border-radius: 5px;
    color: white;
    font-weight: bold;
    text-decoration:none!important;
}
</style>
<center>
<div class="card mb-3 container col-sm-12 col-lg-6 shadow mt-5">
  <div> <img src="<?=$result['image'];?>" class="img-thumbnail mt-1 "></div>
    <div class="card-body">
    <h5 class="card-title"><?=$result['fullname'];?></h5>
    <p class="card-text"><?=$result['about'];?></p>
    <form method="post" action="">
     <a href="send_message.php?id=<?=$id?>" class="button">Share Profile</a>
     <br>

   </form>
  </div>
</div>
</center>

<br>
<br>
<Br>
<br>
<br>
<br>
<Br>
<br>
<?php

include 'footer.php';

?>