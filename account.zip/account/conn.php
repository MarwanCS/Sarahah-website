<?php
session_start();
$hostname="localhost";
$user="ferkary";
$password="abcabcabc";
$db="account";

$conn=mysqli_connect($hostname,$user,$password,$db);

if(!$conn){
	echo "fail";
}

?>
