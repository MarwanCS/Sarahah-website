



<br>
<br>
<br>
<br>
<br>
<br>
<!-- Footer -->
<footer class="page-footer font-small blue" style="background-color: #1A78C3;">

  <!-- Copyright -->
  <div class="footer-copyright text-center py-3" style="color:white">© 2018-<?php $barwar=date("Y");
    echo $barwar; ?> Copyright:
    <a href="https://mdbootstrap.com/education/bootstrap/"style="color:white"> Ferkary.com</a>
  </div>
  <!-- Copyright -->

</footer>
<!-- Footer -->




</body>
</html>