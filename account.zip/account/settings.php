<?php
include 'header.php';
$id=@$_SESSION['user'];
if(!$id){
    header('location:login.php');
}
$query_get_data="SELECT * from users where idusers='$id' ";
$exe=mysqli_query($conn,$query_get_data);
$result=mysqli_fetch_array($exe);

?>



<!-- Default form login -->
<div class="container col-sm-12 col-lg-6 shadow mt-5" >

	
<form class="text-center border border-light p-5" action="" method="post">

    <p class="h4 mb-4">Settings</p>

    <!-- Email -->
    <input type="text" id="fullname" name="fullname" value="<?=$result['fullname'];?>" class="form-control mb-4" placeholder="fullname">

    <!-- Sign in button -->
    <button class="btn btn-info btn-block my-4" name="changeName" style="background-color: #1A78C3;" type="submit">Change</button>




</form>
<!-- Default form login -->
</div>

<?php
if(isset($_POST['changeName'])){
    $fullname=$_POST['fullname'];
    $query_update="UPDATE users set fullname='$fullname' where idusers='$id' ";
    if(mysqli_query($conn,$query_update)){
        echo "<script>alert('Update successfully');</script>";
    }else{
        echo "<script>alert('fail');</script>";
    }
}


?>

<br>
<br>

<?php


include 'footer.php';

?>