
<?php
include 'header.php';

?>


<form method="post" action="">
<div class="input-group md-form form-sm form-2 pl-0 col-lg-4 col-sm-6 col-xs-6 mt-1 container">
  <input class="form-control my-0 py-1 lime-border" name="searchtxt" type="text" placeholder="Search" aria-label="Search">
  <div class="input-group-append">
    <button class="input-group-text lime lighten-2" id="basic-text1">Search</button>
  </div>
</div>
</form>
<style type="text/css">
  .button {
    display: block;
width: 30%;
    background: #4E9CAF;
    padding: 10px;
    text-align: center;
    border-radius: 5px;
    color: white;
    font-weight: bold;
    text-decoration:none!important;
}
</style>
<?php
	$search_word=@$_POST['searchtxt'];
	
	$query_get_all_data="SELECT * from users";
	if($search_word){
		$query_get_all_data="SELECT * from users where fullname like '%$search_word%' ";
	}
	$exe=mysqli_query($conn,$query_get_all_data);

	while($row=mysqli_fetch_assoc($exe)){

		
	?>

<center>
<div class="card mb-3 container col-sm-12 col-lg-6 shadow mt-5">
    <div class="card-body">
    	 <div> <img src="<?=$row['image'];?>" class="img-thumbnail mt-1 "></div>
    <h5 class="card-title"><?=$row['fullname'];?></h5>
    <p class="card-text"><?=$row['about'];?></p>
      <a href="send_message.php?id=<?=$row['idusers'];?>" class="button">Profile</a>
   
  </div>
</div>
</center>

<?php

}

?>









<br>
<br>
<Br>
<br>
<br>
<br>
<Br>
<br>
<?php

include 'footer.php';

?>