<?php
include 'header.php';
include 'functions.php';
$id=@$_SESSION['user'];
if(!$id){
 header('location:login.php');
}


$query_get_message="SELECT * from message where iduser='$id' order by idmessage desc";
$exe=mysqli_query($conn,$query_get_message);

?>





<?php

while($row=mysqli_fetch_assoc($exe)){

?>
<center>
<div class="card mb-3 container col-sm-12 col-lg-6 shadow mt-5">
    <div class="card-body">
   
    <p class="card-text"><?=$row['message'];?> </p>
    <small><?= time_elapsed_string($row['date']);?></small>
   
  </div>
</div>
</center>

<?php
}

?>








<br>
<br>
<Br>
<br>
<br>
<br>
<Br>
<br>
<?php

include 'footer.php';

?>