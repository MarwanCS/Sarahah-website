<?php
include 'header.php';
$id=@$_SESSION['user'];
if($id){
    header('location:profile.php');
}
?>



<!-- Default form login -->
<div class="container col-sm-12 col-lg-6 shadow mt-5" >

	
<form class="text-center border border-light p-5" action="" method="post">

    <p class="h4 mb-4">Sign in</p>

    <!-- Email -->
    <input type="email" id="defaultLoginFormEmail" name="email" class="form-control mb-4" placeholder="E-mail">

    <!-- Password -->
    <input type="password" id="defaultLoginFormPassword" name="password" class="form-control mb-4" placeholder="Password">

   

    <!-- Sign in button -->
    <button class="btn btn-info btn-block my-4" name="submitbtn" style="background-color: #1A78C3;" type="submit">Sign in</button>




</form>
<!-- Default form login -->
</div>

<?php

if(isset($_POST['submitbtn'])){

    $email=$_POST['email'];
    $password=$_POST['password'];
    $query_select="SELECT * from users where email='$email' and password='$password' ";
    $exe=mysqli_query($conn,$query_select);
    $result=mysqli_fetch_array($exe); 
    if($result){
    	$_SESSION['user']=$result['idusers'];
    	$cookie_name = "user";
	    $cookie_value =$result['idusers'];

	    setcookie($cookie_name, $cookie_value, time() +(86400*30), "/");
    
    	header('location:profile.php');
    }else{
        echo "<script>alert('wrong email or password');</script>";
    }

    
    

    
}

?>

<br>
<br>

<?php


include 'footer.php';

?>