<?php

include 'header.php';
$id=@$_GET['id'];

$query_get_data="SELECT * from users where idusers='$id' ";
$exe=mysqli_query($conn,$query_get_data);
$result=mysqli_fetch_array($exe);
?>


<style type="text/css">
    .imagee {
  vertical-align: middle;
  width: 200px;
  height: 200px;
  border-radius: 50%;
}
</style>
<!-- Default form login -->
<div class="container col-sm-12 col-lg-6 shadow mt-5" >

	
<form class="text-center border border-light p-5" action="" method="post" >
    <div> <img src="<?=$result['image'];?>" class="img-thumbnail mt-1 imagee"></div>
    <h3><?=$result['fullname'];?></h3>
    <textarea id="about" class="form-control mb-4" name="message" placeholder="Write your feedback to <?=$result['fullname'];?> " style="height: 180px" ></textarea> 

    <!-- Sign in button -->
    <button class="btn btn-info  my-4" name="sendbtn" style="background-color: #1A78C3;" type="submit">Send</button>

    <!-- Register -->



</form>
<!-- Default form login -->
</div>
<?php

if(isset($_POST['sendbtn'])){


    $message=$_POST['message'];
    $date=date("Y/m/d H:i:s");
    $query_send_message="INSERT into message (iduser,message,date) values ('$id','$message','$date')";
    if($message){
    if(mysqli_query($conn,$query_send_message)){
        echo "<script>alert('message sent successfully');</script>";
    }else{
          echo "<script>alert('fail');</script>";
    }
}else{
   echo "<script>alert('empty message');</script>";   
}


}

?>


<?php

include 'footer.php';

?>