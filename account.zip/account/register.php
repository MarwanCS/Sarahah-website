<?php

include 'header.php';
$id=@$_SESSION['user'];

if($id){
    header('location:profile.php');
}
?>



<!-- Default form login -->
<div class="container col-sm-12 col-lg-6 shadow mt-5" >

	
<form class="text-center border border-light p-5" action="" method="post" enctype="multipart/form-data">

    <p class="h4 mb-4">Sign up</p>

    <!-- Email -->
    <input type="email" id="defaultLoginFormEmail" name="email" class="form-control mb-4" placeholder="E-mail">

    <!-- Password -->
    <input type="password" id="defaultLoginFormPassword" name="pass" class="form-control mb-4" placeholder="Password">

   <!-- Password -->
    <input type="text" id="fullname" name="name" class="form-control mb-4" placeholder="fullname">

    <textarea id="about" class="form-control mb-4" name="about" placeholder="about"></textarea> 
    <input type="file" class="form-control" name="fileToUpload" id="fileToUpload">


    <!-- Sign in button -->
    <button class="btn btn-info btn-block my-4" name="submitbtn" style="background-color: #1A78C3;" type="submit">Register</button>

    <!-- Register -->



</form>
<!-- Default form login -->
</div>

<?php
function upload(){
    $target_dir = "uploads/";

$target_file = $target_dir.rand(100000000,999999999).basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
    if($check !== false) {
        echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }
}
// Check if file already exists
if (file_exists($target_file)) {
    echo "Sorry, file already exists.";
    $uploadOk = 0;
}
// Check file size
if ($_FILES["fileToUpload"]["size"] > 500000) {
    echo "Sorry, your file is too large.";
    $uploadOk = 0;
}
// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
               return $target_file;
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}
}
if(isset($_POST['submitbtn'])){
    $name=$_POST['name'];
    $email=$_POST['email'];
    $about=$_POST['about'];
    $password=$_POST['pass'];
    $img=upload();

    $query_insert="INSERT into users (fullname,email,password,about,image) values ('$name','$email','$password','$about','$img') ";
    if(mysqli_query($conn,$query_insert)){
        echo "<script>alert('success');</script>";
    }else{
    echo "<script>alert('fail');</script>";
    }
    

    
}

?>

<?php

include 'footer.php';

?>